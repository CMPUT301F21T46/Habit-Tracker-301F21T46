package com.example.habit_tracker_301f21t46;

import android.content.Context;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class HabitData {
    private ArrayList<Habit> habitList;
    //TODO get the list of habits which contains each day of a week
    private ArrayList<Habit> habitList_mon;

    private static HabitData instance_mon;
    private static HabitData instance_tue;
    private static HabitData instance_wed;
    private static HabitData instance_thur;
    private static HabitData instance_fri;
    private static HabitData instance_sat;
    private static HabitData instance_sun;

    private final PlannerAdapter mon_pa;
    private final PlannerAdapter tue_pa;
    private final PlannerAdapter wed_pa;
    private final PlannerAdapter thur_pa;
    private final PlannerAdapter fri_pa;
    private final PlannerAdapter sat_pa;
    private final PlannerAdapter sun_pa;

    public HabitData(Context activity, int layout){
        habitList = new ArrayList<Habit>();

        mon_pa = new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);
        tue_pa = new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);
        wed_pa= new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);
        thur_pa = new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);
        fri_pa = new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);
        sat_pa = new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);
        sun_pa = new PlannerAdapter(activity, R.layout.custom_habit_view_layout, habitList);

        ArrayList<String> dofw1 =new ArrayList<String>() ;
        dofw1.add("Mon");
        dofw1.add("Tue");
        dofw1.add("Wed");
        dofw1.add("Thur");
        dofw1.add("Fri");
        dofw1.add("Sat");
        dofw1.add("Sun");

        ArrayList<String> dofw2 =new ArrayList<String>() ;
        dofw2.add("Mon");
        dofw2.add("Wed");
        dofw2.add("Fri");

        ArrayList<String> dofw3 =new ArrayList<String>() ;
        dofw3.add("Sat");
        dofw3.add("Sun");

        //Adding test data
        Habit habit1 = new Habit("Walk Dog", "He's fat", "2000-11-11",dofw1);
        Habit habit2 = new Habit("Got to gym", "My gf left me", "2001-12-12",dofw2);
        Habit habit3 = new Habit("Vibe", "My gf left me", "2001-12-12",dofw3);
        Habit habit4 = new Habit("yeet", "My gf left me", "2001-12-12",dofw1);
        habitList.add(habit1);
        habitList.add(habit2);
        habitList.add(habit3);
        habitList.add(habit4);
    }


    public static HabitData getInstance_mon(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_mon == null){
            instance_mon = new HabitData(activity,layout);
        }
        return instance_mon;
    }
    public static HabitData getInstance_tue(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_tue == null){
            instance_tue = new HabitData(activity,layout);
        }
        return instance_tue;
    }
    public static HabitData getInstance_wed(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_wed == null){
            instance_wed = new HabitData(activity,layout);
        }
        return instance_wed;
    }
    public static HabitData getInstance_thur(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_thur == null){
            instance_thur = new HabitData(activity,layout);
        }
        return instance_thur;
    }
    public static HabitData getInstance_fri(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_fri == null){
            instance_fri = new HabitData(activity,layout);
        }
        return instance_fri;
    }
    public static HabitData getInstance_sat(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_sat == null){
            instance_sat = new HabitData(activity,layout);
        }
        return instance_sat;
    }
    public static HabitData getInstance_sun(Context activity, int layout){
        //Will expose HabitData as a singleton so data can be accessed from other classes
        if (instance_sun == null){
            instance_sun = new HabitData(activity,layout);
        }
        return instance_sun;
    }

    // ----- Getters and Setters -----


    public ArrayList<Habit> getHabitList() {
        return habitList;
    }

    public void setHabitList(ArrayList<Habit> habitList) {
        this.habitList = habitList;
    }

    public PlannerAdapter getMon_pa() {
        return mon_pa;
    }

    public PlannerAdapter getTue_pa() {
        return tue_pa;
    }

    public PlannerAdapter getWed_pa() {
        return wed_pa;
    }

    public PlannerAdapter getThur_pa() {
        return thur_pa;
    }

    public PlannerAdapter getFri_pa() {
        return fri_pa;
    }

    public PlannerAdapter getSat_pa() {
        return sat_pa;
    }

    public PlannerAdapter getSun_pa() {
        return sun_pa;
    }

}

